'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';
import { Search, Plus, Trash2, Save, Send, ChevronDown, ChevronUp } from 'lucide-react';

// Types
interface Client {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
    phone: string;
    companies?: { company_name: string } | { company_name: string }[];
}

interface ApplicationType {
    id: string;
    name: string;
    code: string;
    color_hex: string;
}

interface Product {
    id: string;
    sku: string;
    description: string;
    r_value: string;
    bale_size_sqm: number;
    waste_percentage: number;
}

type SectionType = 'Openings' | 'Insulation';

interface CalculationLine {
    id: string;
    // Openings Fields
    marked_location?: string;
    width_m?: number | null;

    // Insulation Fields
    length_m?: number | null;
    raked_m?: number | null;
    openings_area_sqm?: number | null;
    level?: string;

    // Shared
    height_m?: number | null;
    area_sqm: number;
}

interface Section {
    id: string;
    type: SectionType;
    app_type_id: string | null;
    app_type?: ApplicationType;
    section_color: string;
    product_id: string | null;
    product?: Product;
    notes: string;
    calculation_lines: CalculationLine[];
}

export default function NewRecommendation() {
    const router = useRouter();

    // Client Details
    const [clients, setClients] = useState<Client[]>([]);
    const [selectedClientId, setSelectedClientId] = useState('');
    const [companyName, setCompanyName] = useState('');
    const [siteAddress, setSiteAddress] = useState('');
    const [contactPerson, setContactPerson] = useState('');
    const [contactEmail, setContactEmail] = useState('');

    // Lookup Data
    const [appTypes, setAppTypes] = useState<ApplicationType[]>([]);
    const [products, setProducts] = useState<Product[]>([]);

    // Sections
    const [sections, setSections] = useState<Section[]>([]);
    const [generalNotes, setGeneralNotes] = useState('');

    // Product Search
    const [productSearch, setProductSearch] = useState<{ [key: string]: string }>({});
    const [showProductSuggestions, setShowProductSuggestions] = useState<{ [key: string]: boolean }>({});

    // Load data on mount
    useEffect(() => {
        loadClients();
        loadAppTypes();
        loadProducts();
    }, []);

    const loadClients = async () => {
        const { data } = await supabase
            .from('clients')
            .select('id, first_name, last_name, email, phone, companies(company_name)')
            .order('first_name');
        if (data) setClients(data.filter((c: any) => c.is_active !== false));
    };

    const loadAppTypes = async () => {
        const { data } = await supabase
            .from('app_types')
            .select('*')
            .order('sort_order');
        if (data) setAppTypes(data.filter((a: any) => a.is_active !== false));
    };

    const loadProducts = async () => {
        const { data } = await supabase
            .from('products')
            .select('*')
            .order('sku');
        if (data) setProducts(data.filter((p: any) => p.is_active !== false && p.is_labour !== true));
    };

    // Add new section
    const addSection = (type: SectionType) => {
        const newSection: Section = {
            id: `section-${Date.now()}`,
            type,
            app_type_id: null,
            section_color: '#E5E7EB',
            product_id: null,
            notes: '',
            calculation_lines: []
        };
        setSections([...sections, newSection]);
    };

    // Update section
    const updateSection = (sectionId: string, field: string, value: any) => {
        setSections(sections.map(s => {
            if (s.id === sectionId) {
                const updated = { ...s, [field]: value };

                // Auto-fill color when app type changes
                if (field === 'app_type_id' && value) {
                    const appType = appTypes.find(a => a.id === value);
                    if (appType) {
                        updated.app_type = appType;
                        updated.section_color = appType.color_hex;
                    }
                }

                return updated;
            }
            return s;
        }));
    };

    // Delete section
    const deleteSection = (sectionId: string) => {
        setSections(sections.filter(s => s.id !== sectionId));
    };

    // Add calculation line to section
    const addCalculationLine = (sectionId: string) => {
        setSections(sections.map(s => {
            if (s.id === sectionId) {
                const newLine: CalculationLine = {
                    id: `line-${Date.now()}`,
                    area_sqm: 0
                };
                return { ...s, calculation_lines: [...s.calculation_lines, newLine] };
            }
            return s;
        }));
    };

    // Update calculation line
    const updateCalculationLine = (sectionId: string, lineId: string, field: string, value: any) => {
        setSections(sections.map(s => {
            if (s.id === sectionId) {
                const updatedLines = s.calculation_lines.map(line => {
                    if (line.id === lineId) {
                        const updated = { ...line, [field]: value };

                        // Calculate Area based on Section Type
                        if (s.type === 'Openings') {
                            // Area = Height * Width
                            if (updated.height_m && updated.width_m) {
                                updated.area_sqm = parseFloat((updated.height_m * updated.width_m).toFixed(3));
                            }
                        } else if (s.type === 'Insulation') {
                            // Area = (Length * Height) + (Raked || 0) - (Openings || 0)
                            if (updated.length_m && updated.height_m) {
                                const baseArea = updated.length_m * updated.height_m;
                                const raked = updated.raked_m || 0;
                                const openings = updated.openings_area_sqm || 0;
                                updated.area_sqm = parseFloat((baseArea + raked - openings).toFixed(3));
                            }
                        }

                        return updated;
                    }
                    return line;
                });
                return { ...s, calculation_lines: updatedLines };
            }
            return s;
        }));
    };

    // Delete calculation line
    const deleteCalculationLine = (sectionId: string, lineId: string) => {
        setSections(sections.map(s => {
            if (s.id === sectionId) {
                return { ...s, calculation_lines: s.calculation_lines.filter(l => l.id !== lineId) };
            }
            return s;
        }));
    };

    // Calculate total area for a section
    const getSectionTotalArea = (section: Section) => {
        return section.calculation_lines.reduce((sum, line) => sum + (line.area_sqm || 0), 0);
    };

    // Calculate packs required for a section
    const getSectionPacksRequired = (section: Section) => {
        if (!section.product) return 0;
        const totalArea = getSectionTotalArea(section);
        const wasteMultiplier = 1 + (section.product.waste_percentage / 100);
        const adjustedArea = totalArea * wasteMultiplier;
        return Math.ceil(adjustedArea / section.product.bale_size_sqm);
    };

    // Filter products for search
    const filterProducts = (searchTerm: string) => {
        if (!searchTerm || searchTerm.length < 2) return [];
        const term = searchTerm.toLowerCase();
        return products.filter(p =>
            (p.sku && p.sku.toLowerCase().includes(term)) ||
            (p.description && p.description.toLowerCase().includes(term)) ||
            (p.r_value && p.r_value.toLowerCase().includes(term))
        ).slice(0, 10);
    };

    // Select product for section
    const selectProduct = (sectionId: string, product: Product) => {
        updateSection(sectionId, 'product_id', product.id);
        updateSection(sectionId, 'product', product);
        setProductSearch({ ...productSearch, [sectionId]: product.description });
        setShowProductSuggestions({ ...showProductSuggestions, [sectionId]: false });
    };

    // Save draft
    const saveDraft = async () => {
        alert('Draft saved! (Database integration pending)');
    };

    // Submit for review
    const submitForReview = async () => {
        alert('Submitted for review! (Database integration pending)');
        router.push('/va-workspace');
    };

    return (
        <div className="min-h-screen bg-gray-100 flex flex-col">
            {/* Header */}
            <div className="bg-white border-b border-gray-200 px-6 py-4 flex-none">
                <div className="flex items-center justify-between">
                    <div>
                        <h1 className="text-2xl font-semibold text-[#0066CC]">New Product Recommendation</h1>
                        <p className="text-sm text-gray-500 mt-1">Create a product recommendation for a client</p>
                    </div>
                    <div className="flex items-center gap-4">
                        <button
                            onClick={() => router.push('/va-workspace')}
                            className="px-4 py-2 text-gray-600 hover:text-gray-800"
                        >
                            Cancel
                        </button>
                        <button
                            onClick={saveDraft}
                            className="flex items-center gap-2 px-4 py-2 bg-gray-600 text-white rounded hover:bg-gray-700 transition-colors"
                        >
                            <Save className="w-4 h-4" />
                            Save Draft
                        </button>
                        <button
                            onClick={submitForReview}
                            className="flex items-center gap-2 px-4 py-2 bg-[#0066CC] text-white rounded hover:bg-[#0052a3] transition-colors"
                        >
                            <Send className="w-4 h-4" />
                            Submit
                        </button>
                    </div>
                </div>
            </div>

            {/* Main Content - Split Screen */}
            <div className="flex-1 flex overflow-hidden">
                {/* Left Panel - Calculation Builder */}
                <div className="w-7/12 p-6 overflow-y-auto border-r border-gray-200 bg-gray-50">
                    <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
                        <span className="bg-[#0066CC] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm">1</span>
                        Calculation Builder
                    </h2>

                    {/* Client Details (Compact) */}
                    <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
                        <h3 className="text-sm font-medium text-gray-700 mb-3 uppercase tracking-wide">Client Information</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-medium text-gray-500 mb-1">Select Client</label>
                                <select
                                    value={selectedClientId}
                                    onChange={(e) => setSelectedClientId(e.target.value)}
                                    className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                                >
                                    <option value="">Select client...</option>
                                    {clients.map(c => (
                                        <option key={c.id} value={c.id}>
                                            {c.first_name} {c.last_name}
                                        </option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-xs font-medium text-gray-500 mb-1">Site Address</label>
                                <input
                                    type="text"
                                    value={siteAddress}
                                    onChange={(e) => setSiteAddress(e.target.value)}
                                    className="w-full px-2 py-1.5 border border-gray-300 rounded text-sm"
                                    placeholder="Site Address"
                                />
                            </div>
                        </div>
                    </div>

                    <Trash2 className="w-4 h-4" />
                </button>
            </div>

            <div className="p-4">
                {/* Product Selection (Only for Insulation) */}
                {section.type === 'Insulation' && (
                    <div className="mb-4">
                        <label className="block text-xs font-medium text-gray-500 mb-1">Product</label>
                        <div className="relative">
                            <input
                                type="text"
                                value={productSearch[section.id] || (section.product?.description || '')}
                                onChange={(e) => {
                                    setProductSearch({ ...productSearch, [section.id]: e.target.value });
                                    setShowProductSuggestions({ ...showProductSuggestions, [section.id]: true });
                                }}
                                onFocus={() => setShowProductSuggestions({ ...showProductSuggestions, [section.id]: true })}
                                placeholder="Search product..."
                                className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
                            />
                            {showProductSuggestions[section.id] && productSearch[section.id] && (
                                <div className="absolute z-50 w-full mt-1 bg-white border border-gray-300 rounded shadow-lg max-h-48 overflow-y-auto">
                                    {filterProducts(productSearch[section.id]).map(p => (
                                        <button
                                            key={p.id}
                                            onClick={() => selectProduct(section.id, p)}
                                            className="w-full text-left px-3 py-2 hover:bg-blue-50 text-sm"
                                        >
                                            {p.description}
                                        </button>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {/* Calculation Table */}
                <div className="mb-4 overflow-x-auto">
                    <table className="w-full text-sm border-collapse">
                        <thead>
                            <tr className="bg-gray-50 text-xs text-gray-500 uppercase">
                                {section.type === 'Openings' ? (
                                    <>
                                        <th className="p-2 border text-left w-24">Marked</th>
                                        <th className="p-2 border text-left w-20">Height</th>
                                        <th className="p-2 border text-left w-20">Width</th>
                                        <th className="p-2 border text-left w-24">Area</th>
                                    </>
                                ) : (
                                    <>
                                        <th className="p-2 border text-left w-20">Length</th>
                                        <th className="p-2 border text-left w-20">Height</th>
                                        <th className="p-2 border text-left w-20">Raked</th>
                                        <th className="p-2 border text-left w-20">Openings</th>
                                        <th className="p-2 border text-left w-24">Area</th>
                                        <th className="p-2 border text-left w-16">Level</th>
                                    </>
                                )}
                                <th className="p-2 border w-10"></th>
                            </tr>
                        </thead>
                        <tbody>
                            {section.calculation_lines.map(line => (
                                <tr key={line.id}>
                                    {section.type === 'Openings' ? (
                                        <>
                                            <td className="p-1 border">
                                                <input
                                                    type="text"
                                                    data-testid={`marked-${section.id}-${line.id}`}
                                                    value={line.marked_location || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'marked_location', e.target.value)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                    placeholder="D01"
                                                />
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`height-${section.id}-${line.id}`}
                                                    value={line.height_m || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'height_m', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`width-${section.id}-${line.id}`}
                                                    value={line.width_m || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'width_m', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border bg-gray-50 font-medium text-right" data-testid={`area-${section.id}-${line.id}`}>
                                                {line.area_sqm?.toFixed(3)}
                                            </td>
                                        </>
                                    ) : (
                                        <>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`length-${section.id}-${line.id}`}
                                                    value={line.length_m || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'length_m', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`height-${section.id}-${line.id}`}
                                                    value={line.height_m || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'height_m', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`raked-${section.id}-${line.id}`}
                                                    value={line.raked_m || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'raked_m', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="number"
                                                    step="0.001"
                                                    data-testid={`openings-${section.id}-${line.id}`}
                                                    placeholder="Openings"
                                                    value={line.openings_area_sqm || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'openings_area_sqm', parseFloat(e.target.value) || null)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                                                />
                                            </td>
                                            <td className="p-1 border bg-gray-50 font-medium text-right" data-testid={`area-${section.id}-${line.id}`}>
                                                {line.area_sqm?.toFixed(3)}
                                            </td>
                                            <td className="p-1 border">
                                                <input
                                                    type="text"
                                                    data-testid={`level-${section.id}-${line.id}`}
                                                    value={line.level || ''}
                                                    onChange={(e) => updateCalculationLine(section.id, line.id, 'level', e.target.value)}
                                                    className="w-full p-1 border-none focus:ring-0 text-sm"
                    <button
                                                    onClick={() => addCalculationLine(section.id)}
                                                    className="mt-2 text-xs text-[#0066CC] hover:underline flex items-center gap-1"
                                                >
                                                    <Plus className="w-3 h-3" /> Add Line
                                                </button>
                                            </div>

                                            {/* Totals */}
                                            <div className="flex justify-end gap-6 text-sm">
                                                <div>
                                                    <span className="text-gray-500">Total Area:</span>
                                                    <span className="ml-2 font-semibold">{getSectionTotalArea(section).toFixed(3)} m²</span>
                                                </div>
                                                {section.type === 'Insulation' && section.product && (
                                                    <div>
                                                        <span className="text-gray-500">Packs:</span>
                                                        <span className="ml-2 font-semibold text-[#0066CC]">{getSectionPacksRequired(section)}</span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                </div>
                            ))
                            }

                            {/* Add Section Buttons */}
                            <div className="flex gap-4">
                                <button
                                    onClick={() => addSection('Openings')}
                                    className="flex-1 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-[#0066CC] hover:text-[#0066CC] transition-colors flex items-center justify-center gap-2"
                                >
                                    <Plus className="w-4 h-4" /> Add Openings Section
                                </button>
                                <button
                                    onClick={() => addSection('Insulation')}
                                    className="flex-1 py-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-[#0066CC] hover:text-[#0066CC] transition-colors flex items-center justify-center gap-2"
                                >
                                    <Plus className="w-4 h-4" /> Add Insulation Section
                                </button>
                            </div>
                        </div >
                </div >

                {/* Right Panel - Cover Sheet Preview */}
                < div className="w-5/12 p-8 bg-white overflow-y-auto" >
                    <h2 className="text-lg font-semibold text-gray-800 mb-6 flex items-center gap-2">
                        <span className="bg-[#0066CC] text-white w-6 h-6 rounded-full flex items-center justify-center text-sm">2</span>
                        Cover Sheet Preview
                    </h2>

                    <div className="border border-gray-200 rounded-lg p-8 shadow-sm">
                        <div className="text-center mb-8">
                            <h1 className="text-2xl font-bold text-gray-900">Product Recommendation</h1>
                            <p className="text-gray-500 mt-2">{new Date().toLocaleDateString()}</p>
                        </div>

                        <div className="mb-8">
                            <h3 className="text-sm font-bold text-gray-900 uppercase border-b border-gray-200 pb-2 mb-4">Client Details</h3>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                                <div>
                                    <span className="block text-gray-500">Client Name</span>
                                    <span className="font-medium">
                                        {clients.find(c => c.id === selectedClientId)?.first_name} {clients.find(c => c.id === selectedClientId)?.last_name}
                                    </span>
                                </div>
                                <div>
                                    <span className="block text-gray-500">Site Address</span>
                                    <span className="font-medium">{siteAddress || '-'}</span>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h3 className="text-sm font-bold text-gray-900 uppercase border-b border-gray-200 pb-2 mb-4">Recommendation Summary</h3>
                            <table className="w-full text-sm">
                                <thead>
                                    <tr className="text-left text-gray-500">
                                        <th className="pb-2">Section</th>
                                        <th className="pb-2">Product</th>
                                        <th className="pb-2 text-right">Area</th>
                                        <th className="pb-2 text-right">Packs</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {sections.filter(s => s.type === 'Insulation').map(section => (
                                        <tr key={section.id}>
                                            <td className="py-3">
                                                <div className="font-medium" style={{ color: section.section_color }}>
                                                    {section.app_type?.name || 'Untitled Section'}
                                                </div>
                                            </td>
                                            <td className="py-3 text-gray-600">
                                                {section.product?.description || '-'}
                                                {section.product && <div className="text-xs text-gray-400">{section.product.sku}</div>}
                                            </td>
                                            <td className="py-3 text-right font-medium">
                                                {getSectionTotalArea(section).toFixed(2)} m²
                                            </td>
                                            <td className="py-3 text-right font-medium">
                                                {getSectionPacksRequired(section)}
                                            </td>
                                        </tr>
                                    ))}
                                    {sections.filter(s => s.type === 'Insulation').length === 0 && (
                                        <tr>
                                            <td colSpan={4} className="py-4 text-center text-gray-400 italic">
                                                No insulation sections added yet.
                                            </td>
                                        </tr>
                                    )}
                                </tbody>
                                <tfoot className="border-t border-gray-200">
                                    <tr>
                                        <td colSpan={2} className="pt-4 font-bold text-gray-900">Total</td>
                                        <td className="pt-4 text-right font-bold text-gray-900">
                                            {sections
                                                .filter(s => s.type === 'Insulation')
                                                .reduce((sum, s) => sum + getSectionTotalArea(s), 0)
                                                .toFixed(2)} m²
                                        </td>
                                        <td className="pt-4 text-right font-bold text-[#0066CC]">
                                            {sections
                                                .filter(s => s.type === 'Insulation')
                                                .reduce((sum, s) => sum + getSectionPacksRequired(s), 0)}
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div >
            </div >
        </div >
    );
}